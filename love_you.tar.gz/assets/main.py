
import math
import os
import random
from dataclasses import dataclass
import asyncio
import pygame


SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
PIXEL_SCALE = 1
WIDTH = SCREEN_WIDTH // PIXEL_SCALE
HEIGHT = SCREEN_HEIGHT // PIXEL_SCALE
FPS = 60

ASSET_DIR = os.path.dirname(os.path.abspath(__file__))
CAR_SPRITE_SHEET_FILE = "Our_cars_clean.png"
GLA_CAR_FILE = "gla_clean_crop.png"
GOLF_CAR_FILE = "golf_clean_crop.png"


def clamp(value, minimum=0, maximum=255):
    return max(minimum, min(maximum, value))


def make_surface(size):
    return pygame.Surface(size, pygame.SRCALPHA)


def draw_pixel_heart(surface, x, y, color, scale=1, alpha=255):
    """Draw a tiny procedural pixel heart from a compact 7x6 mask."""
    pattern = [
        "0110110",
        "1111111",
        "1111111",
        "0111110",
        "0011100",
        "0001000",
    ]
    heart_surface = make_surface((7 * scale, 6 * scale))
    rgba = (*color[:3], alpha)
    for row, line in enumerate(pattern):
        for col, bit in enumerate(line):
            if bit == "1":
                pygame.draw.rect(
                    heart_surface,
                    rgba,
                    (col * scale, row * scale, scale, scale),
                )
    surface.blit(heart_surface, (int(x), int(y)))


class Star:
    def __init__(self, x, y, layer):
        self.x = x
        self.y = y
        self.base_x = x
        self.base_y = y
        self.layer = layer
        self.size = random.choice([1, 1, 1, 2])
        self.phase = random.uniform(0, math.tau)
        self.speed = random.uniform(1.4, 3.2)
        self.brightness = random.randint(120, 255)
        self.blink_cooldown = random.uniform(0.0, 3.0)
        self.blink_timer = 0.0

    def update(self, dt, elapsed):
        self.phase += self.speed * dt
        self.x = self.base_x + math.sin(elapsed * 0.14 * self.layer + self.phase) * self.layer
        self.y = self.base_y + math.cos(elapsed * 0.10 * self.layer + self.phase) * 0.4

        self.blink_cooldown -= dt
        if self.blink_cooldown <= 0:
            self.blink_timer = random.uniform(0.12, 0.35)
            self.blink_cooldown = random.uniform(0.6, 4.2)

        if self.blink_timer > 0:
            self.blink_timer -= dt

    def draw(self, surface, parallax):
        twinkle = (math.sin(self.phase * 2.0) + 1) * 0.5
        blink_boost = 90 if self.blink_timer > 0 else 0
        alpha = clamp(int(self.brightness * (0.55 + twinkle * 0.45)) + blink_boost)
        color = (255, 245, 200, alpha)
        x = int((self.x + parallax * self.layer) % WIDTH)
        y = int(self.y)

        if self.size == 1:
            surface.set_at((x, y), color)
        else:
            pygame.draw.rect(surface, color, (x, y, self.size, self.size))


class Moon:
    def __init__(self, x, y, radius):
        self.x = x
        self.y = y
        self.radius = radius
        self.phase = random.uniform(0, math.tau)

    def update(self, dt):
        self.phase += dt * 0.35

    def draw(self, surface):
        pulse = (math.sin(self.phase) + 1) * 0.5
        glow = make_surface((self.radius * 7, self.radius * 7))
        center = glow.get_width() // 2

        # Layered transparent circles create a soft moon halo while preserving pixel edges.
        for i in range(8, 0, -1):
            radius = int(self.radius * (1.0 + i * 0.28))
            alpha = int((12 + pulse * 4) * (9 - i))
            pygame.draw.circle(glow, (255, 234, 176, alpha), (center, center), radius)

        surface.blit(glow, (self.x - center, self.y - center))
        pygame.draw.circle(surface, (255, 241, 190), (int(self.x), int(self.y)), self.radius)
        pygame.draw.circle(surface, (255, 250, 218), (int(self.x - 5), int(self.y - 5)), self.radius - 5)
        pygame.draw.rect(surface, (238, 222, 169), (self.x - 12, self.y + 5, 7, 4))
        pygame.draw.rect(surface, (230, 214, 162), (self.x + 9, self.y - 8, 5, 3))
        pygame.draw.rect(surface, (246, 231, 178), (self.x + 3, self.y + 14, 4, 3))


class Heart:
    def __init__(self, x, y):
        self.x = x + random.uniform(-8, 8)
        self.y = y
        self.age = 0.0
        self.life = random.uniform(2.3, 3.5)
        self.speed = random.uniform(16, 28)
        self.drift = random.uniform(-8, 8)
        self.scale = random.choice([2, 2, 3])
        self.color = random.choice([(255, 84, 128), (255, 112, 163), (255, 190, 206)])

    @property
    def alive(self):
        return self.age < self.life

    def update(self, dt):
        self.age += dt
        progress = self.age / self.life
        self.y -= self.speed * dt
        self.x += math.sin(progress * math.tau * 1.4) * self.drift * dt

    def draw(self, surface):
        progress = self.age / self.life
        alpha = clamp(int(255 * (1.0 - progress)))
        bob = math.sin(progress * math.tau * 3.0) * 2
        draw_pixel_heart(surface, self.x, self.y + bob, self.color, self.scale, alpha)


class FireworkParticle:
    def __init__(self, x, y, angle, speed, color):
        self.x = x
        self.y = y
        self.prev_x = x
        self.prev_y = y
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.color = color
        self.life = random.uniform(0.9, 1.6)
        self.age = 0.0
        self.gravity = random.uniform(26, 44)
        self.drag = random.uniform(0.965, 0.985)
        self.sparkle_phase = random.uniform(0, math.tau)

    @property
    def alive(self):
        return self.age < self.life

    def update(self, dt):
        self.age += dt
        self.prev_x = self.x
        self.prev_y = self.y
        self.vx *= self.drag
        self.vy = self.vy * self.drag + self.gravity * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.sparkle_phase += dt * 15

    def draw(self, surface):
        progress = self.age / self.life
        alpha = clamp(int(255 * (1.0 - progress)))
        trail_alpha = clamp(int(alpha * 0.42))
        color = (*self.color, alpha)
        trail_color = (*self.color, trail_alpha)

        pygame.draw.line(
            surface,
            trail_color,
            (int(self.prev_x), int(self.prev_y)),
            (int(self.x), int(self.y)),
            1,
        )
        if math.sin(self.sparkle_phase) > -0.35:
            pygame.draw.rect(surface, color, (int(self.x), int(self.y), 2, 2))


class Firework:
    PALETTES = [
        [(255, 94, 98), (255, 195, 113), (255, 235, 150)],
        [(85, 211, 255), (166, 132, 255), (255, 149, 213)],
        [(132, 255, 188), (255, 248, 126), (255, 160, 122)],
        [(255, 255, 255), (255, 120, 168), (120, 210, 255)],
    ]

    def __init__(self, x=None, target_y=None, palette=None):
        self.x = random.randint(70, WIDTH - 70) if x is None else x
        self.y = HEIGHT - 92
        self.target_y = random.randint(48, 158) if target_y is None else target_y
        self.vy = -random.uniform(120, 165)
        self.palette = palette or random.choice(self.PALETTES)
        self.color = random.choice(self.palette)
        self.exploded = False
        self.particles = []
        self.trail = []

    @property
    def alive(self):
        return not self.exploded or any(p.alive for p in self.particles)

    def explode(self):
        self.exploded = True
        palette = random.choice(self.PALETTES)
        burst_count = random.randint(58, 86)

        # Two rings plus a few faster sparks make each explosion feel fuller.
        for i in range(burst_count):
            angle = (math.tau / burst_count) * i + random.uniform(-0.05, 0.05)
            speed = random.uniform(38, 92)
            if i % 5 == 0:
                speed *= 1.35
            self.particles.append(FireworkParticle(self.x, self.y, angle, speed, random.choice(palette)))

        for _ in range(22):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(16, 56)
            self.particles.append(FireworkParticle(self.x, self.y, angle, speed, (255, 255, 220)))

    def update(self, dt):
        if not self.exploded:
            self.trail.append((self.x, self.y))
            if len(self.trail) > 10:
                self.trail.pop(0)
            self.y += self.vy * dt
            self.vy += 34 * dt
            if self.y <= self.target_y or self.vy >= -18:
                self.explode()

        for particle in self.particles:
            particle.update(dt)
        self.particles = [particle for particle in self.particles if particle.alive]

    def draw(self, surface):
        if not self.exploded:
            for index, point in enumerate(self.trail):
                alpha = int(26 + 150 * (index / max(1, len(self.trail))))
                pygame.draw.rect(surface, (*self.color, alpha), (int(point[0]), int(point[1]), 2, 2))
            pygame.draw.rect(surface, (255, 246, 184), (int(self.x), int(self.y), 2, 5))

        for particle in self.particles:
            particle.draw(surface)


class HeartFirework(Firework):
    """A special finale firework whose particles draw a big pixel-romantic heart."""

    def __init__(self, x=None, target_y=None):
        super().__init__(
            x=WIDTH // 2 if x is None else x,
            target_y=118 if target_y is None else target_y,
            palette=[(255, 72, 128), (255, 135, 174), (255, 225, 235), (255, 255, 255)],
        )
        self.vy = -170

    def explode(self):
        self.exploded = True
        points = []
        # Classic parametric heart, scaled into a firework burst.
        for i in range(115):
            t = math.tau * i / 115
            hx = 16 * math.sin(t) ** 3
            hy = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
            points.append((hx, hy))

        for hx, hy in points:
            angle = math.atan2(hy, hx)
            speed = math.hypot(hx, hy) * random.uniform(5.1, 6.0)
            color = random.choice(self.palette)
            particle = FireworkParticle(self.x, self.y, angle, speed, color)
            particle.life = random.uniform(1.45, 2.25)
            particle.gravity = random.uniform(10, 20)
            particle.drag = random.uniform(0.974, 0.988)
            self.particles.append(particle)

        # A bright soft core makes the heart feel like a finale.
        for _ in range(42):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(10, 45)
            particle = FireworkParticle(self.x, self.y, angle, speed, random.choice(self.palette))
            particle.life = random.uniform(1.2, 1.9)
            particle.gravity = random.uniform(8, 18)
            self.particles.append(particle)


class Couple:
    def __init__(self, x, y, palette, mirror=False):
        self.x = x
        self.y = y
        self.palette = palette
        self.mirror = mirror
        self.phase = random.uniform(0, math.tau)
        self.heart_timer = random.uniform(0.2, 1.0)

    def update(self, dt, hearts):
        self.phase += dt * 2.0
        self.heart_timer -= dt
        if self.heart_timer <= 0:
            hearts.append(Heart(self.x + random.uniform(-3, 3), self.y - 42))
            self.heart_timer = random.uniform(0.9, 1.7)

    def draw_person(self, surface, offset_x, shirt, hair, skin, breathe, lean, facing):
        px = int(self.x + offset_x + lean)
        py = int(self.y + breathe)
        face_shift = facing * 1

        # Legs, body, arms, and head are all pixel rectangles for a retro look.
        pygame.draw.rect(surface, (44, 39, 62), (px - 10, py - 8, 8, 4))
        pygame.draw.rect(surface, (44, 39, 62), (px + 2, py - 8, 8, 4))
        pygame.draw.rect(surface, shirt, (px - 7, py - 23, 14, 15))
        pygame.draw.rect(surface, skin, (px - 11, py - 20, 5, 4))
        pygame.draw.rect(surface, skin, (px + 6, py - 20, 5, 4))
        pygame.draw.rect(surface, skin, (px - 5 + face_shift, py - 34, 10, 10))
        pygame.draw.rect(surface, hair, (px - 6 + face_shift, py - 38, 12, 6))
        pygame.draw.rect(surface, hair, (px - 7 + face_shift, py - 33, 3, 5))
        pygame.draw.rect(surface, (57, 33, 45), (px + face_shift + facing * 3, py - 30, 2, 2))
        return px, py

    def draw(self, surface):
        breathe = math.sin(self.phase) * 1.2
        cuddle = (math.sin(self.phase * 0.9) + 1) * 0.5
        lean = 1.3 + cuddle * 1.7
        kiss = 1 if math.sin(self.phase * 1.25) > 0.72 else 0
        skin_a, skin_b = self.palette["skin"]
        shirt_a, shirt_b = self.palette["shirts"]
        hair_a, hair_b = self.palette["hair"]

        left_px, left_py = self.draw_person(surface, -8 + kiss, shirt_a, hair_a, skin_a, breathe, lean, 1)
        right_px, right_py = self.draw_person(surface, 8 - kiss, shirt_b, hair_b, skin_b, -breathe * 0.65, -lean, -1)

        # Holding hands between the two characters.
        hand_y = int(self.y - 19 + math.sin(self.phase * 1.4))
        pygame.draw.rect(surface, (255, 207, 177, 230), (int(self.x - 3), hand_y, 6, 3))

        # Tiny kiss sparkle appears only at the closest part of the idle loop.
        if kiss:
            draw_pixel_heart(surface, self.x - 3, self.y - 37, (255, 132, 170), 1, 230)
            pygame.draw.rect(surface, (255, 235, 245, 220), (int(self.x + 5), int(self.y - 37), 2, 2))

        pygame.draw.rect(surface, (255, 197, 205, 210), (int(self.x - 2), int(self.y - 23), 4, 2))
        draw_pixel_heart(surface, self.x - 4, self.y - 52 + math.sin(self.phase * 1.6), (255, 91, 135), 2, 220)


class TextManager:
    def __init__(self):
        self.messages = [
            ("Happy 2 Months \u2764\ufe0f", 0.0, 4.6),
            ("Thank you for every smile, every laugh, and every moment together.", 4.9, 7.2),
            ("More adventures loading... \U0001f495", 12.5, 5.6),
            ("Love you forever, Daniela!", 17.6, 4.0)
        ]
        self.total_duration = 24.0
        self.timer = 0.0
        self.font_large = pygame.font.SysFont("consolas", 36, bold=True) or pygame.font.Font(None, 36)
        self.font_small = pygame.font.SysFont("consolas", 20, bold=True) or pygame.font.Font(None, 20)

    def update(self, dt):
        self.timer = (self.timer + dt) % self.total_duration

    def draw_pixel_message(self, surface, text, center_x, y, alpha, large=False):
        font = self.font_large if large else self.font_small
        heart_tokens = {"\u2764\ufe0f", "\U0001f495"}
        clean_parts = []
        index = 0
        while index < len(text):
            if text[index:index + 2] == "\u2764\ufe0f":
                clean_parts.append("\u2764\ufe0f")
                index += 2
                continue
            if text[index] == "\U0001f495":
                clean_parts.append("\U0001f495")
                index += 1
                continue
            if text[index:index + 2] in heart_tokens:
                clean_parts.append(text[index:index + 2])
                index += 2
            else:
                clean_parts.append(text[index])
                index += 1

        pieces = []
        total_width = 0
        text_color = (255, 232, 219)
        shadow_color = (72, 30, 64)

        for part in clean_parts:
            if part == "\u2764\ufe0f":
                width = 18 if large else 10
                pieces.append(("heart", width, 1))
            elif part == "\U0001f495":
                width = 27 if large else 17
                pieces.append(("heart", width, 2))
            else:
                rendered = font.render(part, False, text_color)
                pieces.append(("text", rendered.get_width(), part))
            total_width += pieces[-1][1]

        x = int(center_x - total_width / 2)
        for kind, width, payload in pieces:
            if kind == "text":
                # Text is rendered character-by-character to keep the procedural heart glyphs crisp.
                shadow = font.render(payload, False, shadow_color)
                char = font.render(payload, False, text_color)
                shadow.set_alpha(alpha)
                char.set_alpha(alpha)
                surface.blit(shadow, (x + 1, y + 1))
                surface.blit(char, (x, y))
            else:
                heart_scale = 3 if large else 2
                if payload == 1:
                    draw_pixel_heart(surface, x, y + (5 if large else 3), (255, 91, 135), heart_scale, alpha)
                else:
                    draw_pixel_heart(surface, x, y + 4, (255, 91, 135), heart_scale, alpha)
                    draw_pixel_heart(surface, x + (10 if large else 7), y + 1, (255, 152, 188), heart_scale, alpha)
            x += width

    def draw(self, surface):
        for text, start, duration in self.messages:
            local = self.timer - start
            if 0 <= local <= duration:
                fade_in = min(1.0, local / 1.2)
                fade_out = min(1.0, (duration - local) / 1.0)
                alpha = clamp(int(255 * min(fade_in, fade_out)))
                large = text.startswith("Happy")
                y = int(HEIGHT * 0.067) if large else int(HEIGHT * 0.115)
                self.draw_pixel_message(surface, text, WIDTH // 2, y, alpha, large)


@dataclass
class ShootingStar:
    x: float
    y: float
    vx: float
    vy: float
    age: float = 0.0
    life: float = 1.1

    @property
    def alive(self):
        return self.age < self.life and self.x < WIDTH + 40 and self.y < HEIGHT / 2

    def update(self, dt):
        self.age += dt
        self.x += self.vx * dt
        self.y += self.vy * dt

    def draw(self, surface):
        alpha = clamp(int(230 * (1 - self.age / self.life)))
        pygame.draw.line(
            surface,
            (255, 246, 208, alpha),
            (int(self.x), int(self.y)),
            (int(self.x - 34), int(self.y - 16)),
            1,
        )
        pygame.draw.rect(surface, (255, 255, 240, alpha), (int(self.x), int(self.y), 2, 2))


class AnniversaryCard:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Happy 2 Months")
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.canvas = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self.clock = pygame.time.Clock()
        self.elapsed = 0.0
        self.running = True

        # Desktop: hide the default arrow and draw a pixel heart cursor instead.
        # Mobile: touchscreens do not have a visible cursor, so taps create
        # floating heart particles using self.cursor_hearts.
        pygame.mouse.set_visible(False)
        self.cursor_hearts = []
        self.last_touch_time = -10.0

        # Mobile-friendly unlock quiz before the anniversary scene.
        # Android/iPhone browsers do not always open the keyboard for a Pygame canvas,
        # so the quiz uses clickable/tappable answer buttons instead of text input.
        self.state = "date_gate"
        self.error_text = ""
        self.quiz_buttons = []

        # Change the options here if you want different answers.
        # The value of "correct" must exactly match one of the option strings.
        self.date_question = "When did we get together?"
        self.date_options = [
            "18 April 2026",
            "19 April 2026",
            "19 Mai 2026",
            "28 Martie 2026",
        ]
        self.correct_date_answer = "19 April 2026"

        self.location_question = "Where was our first date?"
        self.location_options = [
            "Ciric",
            "Palas",
            "Copou",
            "Iulius Mall",
        ]
        self.correct_location_answer = "Ciric"

        self.unlock_font = pygame.font.SysFont("consolas", 34, bold=True) or pygame.font.Font(None, 34)
        self.unlock_small_font = pygame.font.SysFont("consolas", 20, bold=True) or pygame.font.Font(None, 20)
        self.option_font = pygame.font.SysFont("consolas", 24, bold=True) or pygame.font.Font(None, 24)
        self.message_timer = 0.0
        self.love_message_duration = 5.0

        self.moon = Moon(WIDTH - 112, 70, 31)
        self.stars = [
            Star(random.randint(0, WIDTH - 1), random.randint(10, 205), random.uniform(0.2, 1.5))
            for _ in range(175)
        ]
        self.hearts = []
        self.fireworks = []
        self.shooting_stars = []
        self.firework_timer = 1.4
        self.shooting_star_timer = random.uniform(4.0, 9.0)
        self.finale_heart_launched = False
        self.text_manager = TextManager()

        # Small font for license plates on the pixel canvas
        self.plate_font = pygame.font.SysFont("consolas", 10, bold=True) or pygame.font.Font(None, 10)
        self.car_sprites = self.load_car_sprites()

        # Keep one couple only: the original yellow/blue pair.
        self.couples = [
            Couple(
                WIDTH // 2,
                HEIGHT - 55,
                {
                    "skin": [(239, 178, 132), (250, 198, 151)],
                    "shirts": [(255, 215, 0), (115, 203, 255)],
                    "hair": [(52, 31, 34), (91, 54, 39)],
                },
            ),
        ]

    async def run(self):
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0
            dt = min(dt, 1 / 30)

            self.handle_events()
            self.update(dt)
            self.draw()

            await asyncio.sleep(0)

        pygame.quit()

    def get_canvas_pos(self, pos):
        """Convert screen coordinates to the internal 1280x720 canvas coordinates."""
        screen_w, screen_h = self.screen.get_size()
        if screen_w == 0 or screen_h == 0:
            return pos

        x = int(pos[0] * WIDTH / screen_w)
        y = int(pos[1] * HEIGHT / screen_h)
        return x, y

    def spawn_cursor_heart(self, pos):
        """Create a small floating heart at a mouse/touch position."""
        canvas_x, canvas_y = self.get_canvas_pos(pos)
        heart = Heart(canvas_x, canvas_y)
        heart.life = random.uniform(0.8, 1.4)
        heart.speed = random.uniform(22, 36)
        heart.scale = random.choice([1, 2])
        heart.drift = random.uniform(-4, 4)
        self.cursor_hearts.append(heart)

    def handle_quiz_choice(self, choice):
        """Advance the unlock quiz when the player clicks/taps an answer."""
        if self.state == "date_gate":
            if choice == self.correct_date_answer:
                self.state = "location_gate"
                self.error_text = ""
            else:
                self.error_text = "Not that one... try again."

        elif self.state == "location_gate":
            if choice == self.correct_location_answer:
                self.state = "love_message"
                self.error_text = ""
                self.message_timer = 0.0
            else:
                self.error_text = "Almost... choose our first date place."

    def handle_unlock_click(self, pos):
        """Check whether a mouse click/touch landed on one of the answer buttons."""
        if self.state not in ("date_gate", "location_gate"):
            return

        canvas_pos = self.get_canvas_pos(pos)

        for rect, choice in self.quiz_buttons:
            if rect.collidepoint(canvas_pos):
                self.handle_quiz_choice(choice)
                return

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                    continue

                # Desktop convenience: number keys also select answers.
                if self.state in ("date_gate", "location_gate"):
                    if pygame.K_1 <= event.key <= pygame.K_4:
                        index = event.key - pygame.K_1
                        options = self.date_options if self.state == "date_gate" else self.location_options
                        if 0 <= index < len(options):
                            self.handle_quiz_choice(options[index])

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self.spawn_cursor_heart(event.pos)
                self.handle_unlock_click(event.pos)

            elif event.type == pygame.FINGERDOWN:
                # Mobile browser touch support. FINGERDOWN gives normalized 0..1 coordinates.
                pos = (
                    int(event.x * self.screen.get_width()),
                    int(event.y * self.screen.get_height()),
                )
                self.last_touch_time = self.elapsed
                self.spawn_cursor_heart(pos)
                self.handle_unlock_click(pos)

    def update(self, dt):
        self.elapsed += dt

        for heart in self.cursor_hearts:
            heart.update(dt)
        self.cursor_hearts = [heart for heart in self.cursor_hearts if heart.alive]

        if self.state == "love_message":
            self.message_timer += dt
            self.moon.update(dt)
            for star in self.stars:
                star.update(dt, self.elapsed)

            if self.message_timer >= self.love_message_duration:
                self.state = "scene"
                self.message_timer = 0.0

            return

        if self.state != "scene":
            self.moon.update(dt)
            for star in self.stars:
                star.update(dt, self.elapsed)
            return

        self.moon.update(dt)
        self.text_manager.update(dt)

        # Launch a special heart-shaped firework during the final Daniela message.
        finale_window = 17.6 <= self.text_manager.timer <= 18.0
        if finale_window and not self.finale_heart_launched:
            self.fireworks.append(HeartFirework())
            self.finale_heart_launched = True
        elif self.text_manager.timer < 1.0:
            self.finale_heart_launched = False

        for star in self.stars:
            star.update(dt, self.elapsed)

        for couple in self.couples:
            couple.update(dt, self.hearts)

        for heart in self.hearts:
            heart.update(dt)
        self.hearts = [heart for heart in self.hearts if heart.alive]

        self.firework_timer -= dt
        if self.firework_timer <= 0:
            launches = 2 if random.random() < 0.2 else 1
            for _ in range(launches):
                self.fireworks.append(Firework())
            self.firework_timer = random.uniform(1.8, 4.0)

        for firework in self.fireworks:
            firework.update(dt)
        self.fireworks = [firework for firework in self.fireworks if firework.alive]

        self.shooting_star_timer -= dt
        if self.shooting_star_timer <= 0:
            self.shooting_stars.append(
                ShootingStar(
                    x=random.uniform(-20, WIDTH * 0.35),
                    y=random.uniform(24, 115),
                    vx=random.uniform(120, 180),
                    vy=random.uniform(48, 75),
                )
            )
            self.shooting_star_timer = random.uniform(7.0, 13.0)

        for shooting_star in self.shooting_stars:
            shooting_star.update(dt)
        self.shooting_stars = [star for star in self.shooting_stars if star.alive]

    def draw_background(self):
        self.canvas.fill((8, 10, 28))
        for y in range(HEIGHT):
            blend = y / HEIGHT
            r = int(8 + blend * 24)
            g = int(10 + blend * 8)
            b = int(28 + blend * 34)
            pygame.draw.line(self.canvas, (r, g, b), (0, y), (WIDTH, y))

        parallax = math.sin(self.elapsed * 0.08) * 4
        for star in self.stars:
            star.draw(self.canvas, parallax)

        for shooting_star in self.shooting_stars:
            shooting_star.draw(self.canvas)

        self.moon.draw(self.canvas)

        # Distant hills and horizon lights anchor the fireworks.
        pygame.draw.polygon(self.canvas, (16, 24, 45), [(0, HEIGHT - 90), (70, HEIGHT - 126), (170, HEIGHT - 94), (250, HEIGHT - 124), (360, HEIGHT - 92), (WIDTH, HEIGHT - 116), (WIDTH, HEIGHT), (0, HEIGHT)])
        pygame.draw.polygon(self.canvas, (22, 31, 52), [(0, HEIGHT - 67), (92, HEIGHT - 93), (205, HEIGHT - 70), (322, HEIGHT - 96), (455, HEIGHT - 68), (WIDTH, HEIGHT - 88), (WIDTH, HEIGHT), (0, HEIGHT)])
        for x in range(28, WIDTH, 53):
            sparkle = 40 + int((math.sin(self.elapsed * 2 + x) + 1) * 25)
            pygame.draw.rect(self.canvas, (sparkle, sparkle - 8, 74), (x, HEIGHT - 82, 2, 2))

    def draw_picnic_scene(self):
        # High-detail 3/4 rear-side car sprites, scaled smaller and pushed into the corners.
        # Keep the two PNG files in the same folder as this script.
        self.draw_car_sprite(
            "gla",
            70,
            HEIGHT - 160,
            230                 # ~10% bigger
        )

        self.draw_car_sprite(
            "golf",
            WIDTH - 300,
            HEIGHT - 155,
            225                 # ~10% bigger
        )

        # Smaller cozy picnic blanket, same pink/purple checkered style.
        blanket_x = WIDTH // 2 - 115
        blanket_y = HEIGHT - 42
        blanket_w = 230

        glow = make_surface((blanket_w + 80, 78))
        glow_alpha = 26 + int((math.sin(self.elapsed * 1.8) + 1) * 12)
        pygame.draw.ellipse(glow, (255, 118, 165, glow_alpha), (0, 8, blanket_w + 80, 58))
        self.canvas.blit(glow, (blanket_x - 40, blanket_y - 20))

        # Blanket base.
        pygame.draw.polygon(
            self.canvas,
            (139, 57, 91),
            [
                (blanket_x, blanket_y),
                (blanket_x + blanket_w, blanket_y),
                (blanket_x + blanket_w + 25, HEIGHT - 14),
                (blanket_x - 25, HEIGHT - 14),
            ],
        )

        # Blanket stripes.
        for offset in range(0, blanket_w + 28, 20):
            pygame.draw.line(
                self.canvas,
                (226, 98, 121),
                (blanket_x + offset, blanket_y),
                (blanket_x + offset - 20, HEIGHT - 14),
                2,
            )
        for y in range(blanket_y + 7, HEIGHT - 14, 10):
            pygame.draw.line(
                self.canvas,
                (89, 48, 89),
                (blanket_x - 18, y),
                (blanket_x + blanket_w + 20, y),
                1,
            )

        # Fairy lights around the front/top edge of the blanket.
        light_colors = [
            (255, 124, 174),
            (255, 230, 140),
            (140, 220, 255),
            (255, 180, 210),
        ]
        for i in range(14):
            lx = blanket_x - 5 + i * 17
            ly = blanket_y - 3 + int(math.sin(self.elapsed * 2.0 + i) * 2)
            alpha = clamp(int(150 + 90 * ((math.sin(self.elapsed * 3.2 + i) + 1) * 0.5)))
            pygame.draw.circle(self.canvas, (*light_colors[i % len(light_colors)], alpha), (lx, ly), 2)

        # Soft sparkle pixels on the blanket.
        for i in range(12):
            sparkle_x = blanket_x + 8 + (i * 17) % max(1, blanket_w - 10)
            sparkle_y = blanket_y + 4 + (i * 7) % 24
            alpha = clamp(int(70 + 115 * ((math.sin(self.elapsed * 2.4 + i) + 1) * 0.5)))
            pygame.draw.rect(self.canvas, (255, 221, 232, alpha), (sparkle_x, sparkle_y, 2, 2))

        # Woven picnic basket.
        basket_x = blanket_x + 34
        basket_y = blanket_y + 5
        pygame.draw.rect(self.canvas, (126, 78, 42), (basket_x, basket_y + 4, 36, 19))
        pygame.draw.rect(self.canvas, (167, 112, 58), (basket_x + 2, basket_y + 2, 32, 18))
        pygame.draw.arc(self.canvas, (208, 153, 84), (basket_x + 7, basket_y - 10, 22, 18), math.pi, math.tau, 3)
        pygame.draw.rect(self.canvas, (96, 54, 32), (basket_x, basket_y + 13, 36, 2))
        for x in range(4, 34, 6):
            pygame.draw.line(self.canvas, (206, 150, 78), (basket_x + x, basket_y + 3), (basket_x + x - 4, basket_y + 22), 1)
        for x in range(4, 34, 6):
            pygame.draw.line(self.canvas, (105, 62, 36), (basket_x + x - 3, basket_y + 3), (basket_x + x + 2, basket_y + 22), 1)

        # Strawberry bowl.
        bowl_cx = blanket_x + 91
        bowl_cy = blanket_y + 24
        pygame.draw.ellipse(self.canvas, (235, 235, 235), (bowl_cx - 16, bowl_cy + 5, 34, 10))
        pygame.draw.ellipse(self.canvas, (150, 45, 68), (bowl_cx - 13, bowl_cy + 2, 28, 10))
        pygame.draw.ellipse(self.canvas, (221, 87, 105), (bowl_cx - 10, bowl_cy, 22, 8))
        for sx, sy in [(-6, -2), (1, -5), (7, -1), (-1, 2), (10, 3)]:
            pygame.draw.circle(self.canvas, (226, 58, 78), (bowl_cx + sx, bowl_cy + sy), 4)
            pygame.draw.rect(self.canvas, (76, 174, 80), (bowl_cx + sx - 1, bowl_cy + sy - 5, 2, 2))

        # Sandwich plate.
        plate_x = blanket_x + 132
        plate_y = blanket_y + 18
        pygame.draw.ellipse(self.canvas, (235, 235, 235), (plate_x, plate_y + 10, 56, 13))
        pygame.draw.ellipse(self.canvas, (205, 205, 205), (plate_x + 4, plate_y + 12, 48, 8), 1)

        # Three simple triangular sandwiches.
        sandwich_points = [
            (plate_x + 7, plate_y + 16, plate_x + 20, plate_y + 16, plate_x + 14, plate_y),
            (plate_x + 21, plate_y + 16, plate_x + 34, plate_y + 16, plate_x + 28, plate_y),
            (plate_x + 35, plate_y + 16, plate_x + 48, plate_y + 16, plate_x + 42, plate_y),
        ]
        for left_x, base_y1, right_x, base_y2, top_x, top_y in sandwich_points:
            pygame.draw.polygon(
                self.canvas,
                (245, 220, 170),
                [(left_x, base_y1), (right_x, base_y2), (top_x, top_y)],
            )
            pygame.draw.line(self.canvas, (190, 145, 85), (left_x + 1, base_y1 - 1), (right_x - 1, base_y2 - 1), 1)
            pygame.draw.line(self.canvas, (90, 180, 90), (left_x + 3, base_y1 - 6), (right_x - 3, base_y2 - 6), 2)
            pygame.draw.line(self.canvas, (225, 80, 75), (left_x + 4, base_y1 - 3), (right_x - 4, base_y2 - 3), 1)

        # A tiny pizza slice as an extra easy-to-read snack.
        pizza_x = blanket_x + 200
        pizza_y = blanket_y + 28
        pygame.draw.polygon(
            self.canvas,
            (255, 220, 130),
            [(pizza_x, pizza_y), (pizza_x + 20, pizza_y), (pizza_x + 10, pizza_y - 18)],
        )
        pygame.draw.line(self.canvas, (210, 90, 70), (pizza_x + 4, pizza_y - 5), (pizza_x + 16, pizza_y - 5), 2)
        pygame.draw.circle(self.canvas, (200, 65, 60), (pizza_x + 8, pizza_y - 10), 2)
        pygame.draw.circle(self.canvas, (200, 65, 60), (pizza_x + 13, pizza_y - 4), 2)
        pygame.draw.rect(self.canvas, (85, 180, 85), (pizza_x + 10, pizza_y - 8, 4, 2))

        # Rose
        rose_stem_x = blanket_x + 235

        # Stem (taller)
        pygame.draw.line(
            self.canvas,
            (60, 180, 90),
            (rose_stem_x, blanket_y + 31),
            (rose_stem_x + 8, blanket_y - 2),
            2
        )

        pygame.draw.polygon(
            self.canvas,
            (75, 185, 95),
            [
                (rose_stem_x + 2, blanket_y + 16),
                (rose_stem_x + 10, blanket_y + 12),
                (rose_stem_x + 6, blanket_y + 20)
            ]
        )

        pygame.draw.circle(
            self.canvas,
            (220, 70, 110),
            (rose_stem_x + 8, blanket_y - 3),
            4
        )

        pygame.draw.circle(
            self.canvas,
            (255, 130, 170),
            (rose_stem_x + 5, blanket_y - 3),
            2
        )
        # A few decorative flower petals only, not too crowded.
        for px, py in [(16, 30), (72, 35), (115, 13), (186, 36), (220, 30)]:
            pygame.draw.circle(self.canvas, (255, 140, 180), (blanket_x + px, blanket_y + py), 2)

        # Tiny candle / warm lamp near the couple.
        pygame.draw.rect(self.canvas, (73, 39, 58), (WIDTH // 2 - 4, HEIGHT - 48, 8, 10))
        pygame.draw.rect(self.canvas, (255, 215, 137), (WIDTH // 2 - 3, HEIGHT - 54, 6, 6))
        pygame.draw.rect(self.canvas, (255, 247, 184, 180), (WIDTH // 2 - 14, HEIGHT - 62, 28, 9))

        for couple in self.couples:
            couple.draw(self.canvas)

        for heart in self.hearts:
            heart.draw(self.canvas)


    def load_car_sprites(self):
        """Load the final cropped transparent car sprites directly.

        This version is browser/pygbag friendly because it does not use
        pygame.surfarray or NumPy. Keep these PNG files in the same folder
        as this script:
        - gla_clean_crop.png
        - golf_clean_crop.png
        """
        gla_path = os.path.join(ASSET_DIR, GLA_CAR_FILE)
        golf_path = os.path.join(ASSET_DIR, GOLF_CAR_FILE)

        sprites = {
            "gla": None,
            "golf": None,
        }

        if os.path.exists(gla_path):
            try:
                sprites["gla"] = pygame.image.load(gla_path).convert_alpha()
            except pygame.error:
                sprites["gla"] = None

        if os.path.exists(golf_path):
            try:
                sprites["golf"] = pygame.image.load(golf_path).convert_alpha()
            except pygame.error:
                sprites["golf"] = None

        return sprites

    def draw_car_sprite(self, key, x, y, target_width):
        """Draw a 3/4 pixel-art car sprite in the corner."""
        sprite = self.car_sprites.get(key)

        if sprite is None:
            # Fallback only if image files are missing. If you see this, check
            # that the PNGs are in the same folder as this script.
            if key == "gla":
                self.draw_car(x, y + 45, (245, 245, 238), "IS 25 RAR", model="GLA", scale=2.2)
            else:
                self.draw_car(x, y + 45, (20, 22, 28), "IS 12 RDI", model="Golf", scale=2.2)
            return

        scale = target_width / sprite.get_width()
        target_height = int(sprite.get_height() * scale)

        # Normal scale keeps the sprite/pixel look. Do not use smoothscale here.
        car = pygame.transform.smoothscale(sprite, (target_width, target_height))

        # Align bottom to the requested y area so different original crop heights
        # sit naturally on the same ground line.
        self.canvas.blit(car, (int(x), int(y)))


    def draw_car(self, x, y, color, plate, model="Car", flipped=False, scale=1.0):
        """Draw a front-facing pixel-art car sprite.

        The older version drew side-profile cars. This version is intentionally
        camera-facing so the plate, grille, badges, headlights, and bumper shape
        are visible. The ``flipped`` argument is kept for compatibility, but a
        front view does not need mirroring.
        """
        model_key = model.lower()
        unit = max(3, int(round(scale)))

        def shade(base_color, amount, lift=0):
            return tuple(clamp(int(channel * amount + lift)) for channel in base_color[:3])

        def put_rect(surface, rect, fill, outline=None):
            pygame.draw.rect(surface, fill, rect)
            if outline is not None:
                pygame.draw.rect(surface, outline, rect, 1)

        def draw_vw_badge(surface, cx, cy):
            # Tiny but readable VW-inspired badge: circle plus V/W line hints.
            silver = (225, 229, 232)
            dark = (25, 28, 36)
            pygame.draw.circle(surface, silver, (cx, cy), 4)
            pygame.draw.circle(surface, dark, (cx, cy), 3)
            pygame.draw.line(surface, silver, (cx - 2, cy - 2), (cx, cy + 1), 1)
            pygame.draw.line(surface, silver, (cx + 2, cy - 2), (cx, cy + 1), 1)
            pygame.draw.line(surface, silver, (cx - 2, cy + 1), (cx - 1, cy + 3), 1)
            pygame.draw.line(surface, silver, (cx - 1, cy + 3), (cx, cy + 1), 1)
            pygame.draw.line(surface, silver, (cx, cy + 1), (cx + 1, cy + 3), 1)
            pygame.draw.line(surface, silver, (cx + 1, cy + 3), (cx + 2, cy + 1), 1)

        def draw_mercedes_star(surface, cx, cy):
            # Three-pointed star in a circle, simplified for a tiny pixel sprite.
            silver = (226, 228, 225)
            dark = (19, 21, 25)
            pygame.draw.circle(surface, silver, (cx, cy), 5)
            pygame.draw.circle(surface, dark, (cx, cy), 4)
            pygame.draw.line(surface, silver, (cx, cy), (cx, cy - 4), 1)
            pygame.draw.line(surface, silver, (cx, cy), (cx - 4, cy + 3), 1)
            pygame.draw.line(surface, silver, (cx, cy), (cx + 4, cy + 3), 1)

        if model_key.startswith("gla"):
            # 2016 GLA cues: taller crossover stance, roof rails, big Mercedes
            # grille/star, wide lower intake, pronounced arches, higher bumper.
            sprite_w, sprite_h = 78, 46
            plate_rect_u = pygame.Rect(27, 29, 24, 5)
            sprite = make_surface((sprite_w, sprite_h))

            body = color[:3]
            outline = (18, 19, 24)
            glass = (135, 167, 190)
            glass_dark = (38, 48, 61)
            silver = (205, 209, 211)
            chrome = (232, 235, 235)
            black = (12, 13, 16)
            bumper_shadow = (176, 178, 176)
            body_shadow = shade(body, 0.72)
            body_deep = shade(body, 0.52)
            body_high = shade(body, 1.03, 8)
            lamp = (247, 248, 225)
            lamp_cool = (178, 211, 226)

            # Tires sit wider and lower to read as a crossover from the front.
            pygame.draw.rect(sprite, (8, 9, 12), (7, 33, 11, 12))
            pygame.draw.rect(sprite, (8, 9, 12), (60, 33, 11, 12))
            pygame.draw.rect(sprite, (38, 40, 46), (9, 34, 7, 10))
            pygame.draw.rect(sprite, (38, 40, 46), (62, 34, 7, 10))

            # Body outline and tall front fascia.
            pygame.draw.polygon(sprite, outline, [(5, 18), (10, 11), (23, 5), (55, 5), (68, 11), (73, 18), (76, 31), (68, 39), (10, 39), (2, 31)])
            pygame.draw.polygon(sprite, body_shadow, [(7, 18), (13, 11), (25, 6), (53, 6), (65, 11), (71, 18), (73, 30), (66, 37), (12, 37), (5, 30)])
            pygame.draw.polygon(sprite, body, [(9, 17), (15, 11), (26, 7), (52, 7), (63, 11), (69, 17), (71, 29), (64, 35), (14, 35), (7, 29)])

            # Roof, rails, windshield, and mirrors.
            pygame.draw.rect(sprite, outline, (22, 2, 34, 2))
            pygame.draw.rect(sprite, silver, (17, 4, 8, 1))
            pygame.draw.rect(sprite, silver, (53, 4, 8, 1))
            pygame.draw.rect(sprite, outline, (5, 17, 7, 3))
            pygame.draw.rect(sprite, outline, (66, 17, 7, 3))
            pygame.draw.polygon(sprite, outline, [(17, 7), (61, 7), (67, 18), (11, 18)])
            pygame.draw.polygon(sprite, glass_dark, [(20, 8), (58, 8), (63, 17), (15, 17)])
            pygame.draw.polygon(sprite, glass, [(22, 9), (38, 9), (38, 16), (16, 16)])
            pygame.draw.polygon(sprite, (121, 153, 178), [(40, 9), (56, 9), (62, 16), (40, 16)])
            pygame.draw.rect(sprite, (26, 31, 39), (38, 8, 2, 10))
            pygame.draw.rect(sprite, (219, 236, 244), (24, 10, 8, 1))
            pygame.draw.rect(sprite, (219, 236, 244), (45, 10, 8, 1))

            # Hood shape and power-dome hints.
            pygame.draw.polygon(sprite, body_high, [(16, 18), (62, 18), (55, 27), (23, 27)])
            pygame.draw.line(sprite, body_shadow, (27, 18), (24, 27), 1)
            pygame.draw.line(sprite, body_shadow, (51, 18), (54, 27), 1)
            pygame.draw.rect(sprite, (205, 207, 205), (38, 19, 2, 1))

            # Angular headlights.
            pygame.draw.polygon(sprite, outline, [(8, 20), (21, 18), (24, 21), (19, 25), (9, 25), (5, 23)])
            pygame.draw.polygon(sprite, outline, [(70, 20), (57, 18), (54, 21), (59, 25), (69, 25), (73, 23)])
            pygame.draw.polygon(sprite, lamp, [(10, 21), (21, 19), (22, 21), (18, 23), (10, 24), (7, 23)])
            pygame.draw.polygon(sprite, lamp, [(68, 21), (57, 19), (56, 21), (60, 23), (68, 24), (71, 23)])
            pygame.draw.rect(sprite, lamp_cool, (14, 22, 4, 1))
            pygame.draw.rect(sprite, lamp_cool, (60, 22, 4, 1))

            # Mercedes twin-slat grille with central star.
            pygame.draw.rect(sprite, black, (21, 20, 36, 8))
            pygame.draw.rect(sprite, chrome, (20, 19, 38, 1))
            pygame.draw.rect(sprite, chrome, (20, 27, 38, 1))
            pygame.draw.rect(sprite, chrome, (24, 22, 30, 1))
            pygame.draw.rect(sprite, chrome, (24, 25, 30, 1))
            for gx in range(23, 55, 4):
                pygame.draw.rect(sprite, (32, 33, 36), (gx, 21, 1, 6))
            draw_mercedes_star(sprite, 39, 24)

            # Bumper, lower intake, fog lamps, and silver skid-plate hint.
            pygame.draw.polygon(sprite, bumper_shadow, [(11, 31), (25, 28), (53, 28), (67, 31), (63, 37), (15, 37)])
            pygame.draw.rect(sprite, black, (18, 34, 42, 4))
            for mx in range(20, 59, 4):
                pygame.draw.rect(sprite, (28, 29, 32), (mx, 35, 2, 2))
            pygame.draw.rect(sprite, (24, 24, 27), (9, 32, 8, 5))
            pygame.draw.rect(sprite, (24, 24, 27), (61, 32, 8, 5))
            pygame.draw.rect(sprite, (233, 233, 221), (11, 34, 4, 2))
            pygame.draw.rect(sprite, (233, 233, 221), (63, 34, 4, 2))
            pygame.draw.rect(sprite, chrome, (25, 38, 28, 2))
            pygame.draw.rect(sprite, body_deep, (15, 39, 48, 2))
            pygame.draw.rect(sprite, outline, (8, 38, 62, 2))

        else:
            # 2008 Golf Mk5 cues: lower hatchback shape, round twin headlights,
            # compact front, VW badge, simple horizontal grille, lower ride height.
            sprite_w, sprite_h = 70, 39
            plate_rect_u = pygame.Rect(23, 23, 24, 5)
            sprite = make_surface((sprite_w, sprite_h))

            body = color[:3]
            outline = (13, 16, 27)
            glass = (121, 170, 210)
            glass_dark = (33, 45, 64)
            black = (13, 14, 19)
            chrome = (205, 214, 220)
            body_shadow = shade(body, 0.64)
            body_deep = shade(body, 0.43)
            body_high = shade(body, 1.16, 5)
            lamp = (242, 245, 222)
            lamp_ring = (160, 187, 203)

            # Lower, narrower tire stance than the GLA.
            pygame.draw.rect(sprite, (8, 9, 13), (6, 28, 10, 10))
            pygame.draw.rect(sprite, (8, 9, 13), (54, 28, 10, 10))
            pygame.draw.rect(sprite, (36, 39, 48), (8, 29, 6, 8))
            pygame.draw.rect(sprite, (36, 39, 48), (56, 29, 6, 8))

            # Compact hatchback body.
            pygame.draw.polygon(sprite, outline, [(6, 15), (12, 9), (23, 5), (47, 5), (58, 9), (64, 15), (66, 26), (60, 32), (10, 32), (4, 26)])
            pygame.draw.polygon(sprite, body_shadow, [(8, 15), (14, 10), (24, 6), (46, 6), (56, 10), (62, 15), (63, 25), (58, 30), (12, 30), (7, 25)])
            pygame.draw.polygon(sprite, body, [(10, 14), (16, 10), (25, 7), (45, 7), (54, 10), (60, 14), (61, 24), (56, 29), (14, 29), (9, 24)])

            # Windshield, low roof, and side mirrors.
            pygame.draw.rect(sprite, outline, (24, 3, 22, 2))
            pygame.draw.rect(sprite, outline, (5, 14, 6, 3))
            pygame.draw.rect(sprite, outline, (59, 14, 6, 3))
            pygame.draw.polygon(sprite, outline, [(18, 7), (52, 7), (58, 15), (12, 15)])
            pygame.draw.polygon(sprite, glass_dark, [(20, 8), (50, 8), (55, 14), (15, 14)])
            pygame.draw.polygon(sprite, glass, [(22, 9), (34, 9), (34, 14), (16, 14)])
            pygame.draw.polygon(sprite, (107, 150, 190), [(36, 9), (48, 9), (54, 14), (36, 14)])
            pygame.draw.rect(sprite, (26, 32, 45), (34, 8, 2, 7))
            pygame.draw.rect(sprite, (205, 229, 243), (23, 10, 6, 1))
            pygame.draw.rect(sprite, (205, 229, 243), (39, 10, 6, 1))

            # Hood and Golf-style soft central nose.
            pygame.draw.polygon(sprite, body_high, [(14, 15), (56, 15), (49, 22), (21, 22)])
            pygame.draw.line(sprite, body_shadow, (25, 15), (22, 22), 1)
            pygame.draw.line(sprite, body_shadow, (45, 15), (48, 22), 1)
            pygame.draw.rect(sprite, body_shadow, (33, 17, 4, 1))

            # Roundish Mk5 Golf headlights with twin-circle impression.
            pygame.draw.polygon(sprite, outline, [(8, 17), (20, 15), (25, 18), (23, 23), (11, 23), (6, 21)])
            pygame.draw.polygon(sprite, outline, [(62, 17), (50, 15), (45, 18), (47, 23), (59, 23), (64, 21)])
            pygame.draw.polygon(sprite, lamp, [(10, 18), (20, 16), (23, 18), (21, 22), (12, 22), (8, 20)])
            pygame.draw.polygon(sprite, lamp, [(60, 18), (50, 16), (47, 18), (49, 22), (58, 22), (62, 20)])
            pygame.draw.circle(sprite, lamp_ring, (15, 19), 2)
            pygame.draw.circle(sprite, lamp_ring, (20, 19), 2)
            pygame.draw.circle(sprite, lamp_ring, (55, 19), 2)
            pygame.draw.circle(sprite, lamp_ring, (50, 19), 2)
            pygame.draw.rect(sprite, (255, 238, 144), (8, 22, 3, 1))
            pygame.draw.rect(sprite, (255, 238, 144), (59, 22, 3, 1))

            # VW horizontal grille and badge.
            pygame.draw.rect(sprite, black, (23, 17, 24, 6))
            pygame.draw.rect(sprite, chrome, (24, 18, 22, 1))
            pygame.draw.rect(sprite, chrome, (24, 21, 22, 1))
            pygame.draw.rect(sprite, (38, 44, 63), (26, 19, 18, 2))
            draw_vw_badge(sprite, 35, 20)

            # Bumper and lower intakes.
            pygame.draw.polygon(sprite, body_shadow, [(9, 25), (21, 23), (49, 23), (61, 25), (57, 31), (13, 31)])
            pygame.draw.rect(sprite, black, (18, 29, 34, 4))
            pygame.draw.rect(sprite, (34, 37, 48), (21, 30, 28, 1))
            pygame.draw.rect(sprite, black, (8, 27, 8, 4))
            pygame.draw.rect(sprite, black, (54, 27, 8, 4))
            pygame.draw.circle(sprite, (226, 226, 205), (12, 29), 2)
            pygame.draw.circle(sprite, (226, 226, 205), (58, 29), 2)
            pygame.draw.rect(sprite, body_deep, (13, 33, 44, 2))
            pygame.draw.rect(sprite, outline, (10, 32, 50, 2))

        # Front license plate background. Text is rendered after scaling so it
        # stays readable even with a tiny source sprite.
        pygame.draw.rect(sprite, (245, 246, 235), plate_rect_u)
        pygame.draw.rect(sprite, (205, 210, 205), (plate_rect_u.x, plate_rect_u.bottom - 1, plate_rect_u.width, 1))
        pygame.draw.rect(sprite, (37, 50, 115), (plate_rect_u.x, plate_rect_u.y, 2, plate_rect_u.height))

        final_car = pygame.transform.scale(sprite, (sprite_w * unit, sprite_h * unit))

        # Soft oval shadow directly below the front-facing car.
        shadow_surface = make_surface((sprite_w * unit + 28, 18))
        pygame.draw.ellipse(shadow_surface, (0, 0, 0, 105), (0, 3, shadow_surface.get_width(), 11))
        self.canvas.blit(shadow_surface, (int(x - 14), int(y + sprite_h * unit - 10)))

        # Subtle symmetrical headlight glow that faces the viewer.
        glow_surface = make_surface((sprite_w * unit, sprite_h * unit))
        glow_alpha = 24 + int((math.sin(self.elapsed * 2.1) + 1) * 8)
        left_glow_x = int(sprite_w * unit * 0.15)
        right_glow_x = int(sprite_w * unit * 0.66)
        glow_y = int(18 * unit)
        glow_w = 12 * unit
        glow_h = 5 * unit
        pygame.draw.ellipse(glow_surface, (255, 238, 164, glow_alpha), (left_glow_x, glow_y, glow_w, glow_h))
        pygame.draw.ellipse(glow_surface, (255, 238, 164, glow_alpha), (right_glow_x, glow_y, glow_w, glow_h))
        self.canvas.blit(glow_surface, (int(x), int(y)))

        # Plate text on the scaled car.
        plate_rect = pygame.Rect(
            plate_rect_u.x * unit,
            plate_rect_u.y * unit,
            plate_rect_u.width * unit,
            plate_rect_u.height * unit,
        )
        max_font_size = clamp(int(unit * 3.1), 8, 15)
        plate_surf = None
        for size in range(max_font_size, 6, -1):
            trial_font = pygame.font.SysFont("consolas", size, bold=True) or pygame.font.Font(None, size)
            trial_surf = trial_font.render(plate, False, (15, 15, 15))
            if trial_surf.get_width() <= plate_rect.width - 4 and trial_surf.get_height() <= plate_rect.height:
                plate_surf = trial_surf
                break
        if plate_surf is None:
            fallback_font = pygame.font.SysFont("consolas", 7, bold=True) or pygame.font.Font(None, 7)
            plate_surf = fallback_font.render(plate, False, (15, 15, 15))

        tx = plate_rect.x + (plate_rect.width - plate_surf.get_width()) // 2
        ty = plate_rect.y + (plate_rect.height - plate_surf.get_height()) // 2
        final_car.blit(plate_surf, (tx, ty))

        self.canvas.blit(final_car, (int(x), int(y)))

    def draw_unlock_screen(self):
        self.draw_background()
        self.quiz_buttons = []

        if self.state == "date_gate":
            title = self.date_question
            hint = "Tap the correct date"
            options = self.date_options
        else:
            title = self.location_question
            hint = "Tap the correct location"
            options = self.location_options

        title_surf = self.unlock_font.render(title, False, (255, 232, 219))
        hint_surf = self.unlock_small_font.render(hint, False, (190, 160, 190))
        error_surf = self.unlock_small_font.render(self.error_text, False, (255, 120, 160))

        self.canvas.blit(title_surf, (WIDTH // 2 - title_surf.get_width() // 2, HEIGHT // 2 - 165))
        self.canvas.blit(hint_surf, (WIDTH // 2 - hint_surf.get_width() // 2, HEIGHT // 2 - 120))

        button_w = 520
        button_h = 58
        gap = 16
        start_y = HEIGHT // 2 - 65

        for index, option in enumerate(options):
            x = WIDTH // 2 - button_w // 2
            y = start_y + index * (button_h + gap)
            rect = pygame.Rect(x, y, button_w, button_h)
            self.quiz_buttons.append((rect, option))

            pulse = (math.sin(self.elapsed * 2.5 + index) + 1) * 0.5
            fill = (24, 20, 50)
            border = (255, 120 + int(pulse * 40), 170)

            pygame.draw.rect(self.canvas, fill, rect, border_radius=10)
            pygame.draw.rect(self.canvas, border, rect, 2, border_radius=10)

            number_text = f"{index + 1}."
            number_surf = self.option_font.render(number_text, False, (255, 150, 185))
            option_surf = self.option_font.render(option, False, (255, 245, 220))

            self.canvas.blit(number_surf, (rect.x + 24, rect.y + 15))
            self.canvas.blit(option_surf, (rect.x + 78, rect.y + 15))

        if self.error_text:
            self.canvas.blit(error_surf, (WIDTH // 2 - error_surf.get_width() // 2, start_y + 4 * (button_h + gap) + 8))

    def draw_love_message(self):
        self.draw_background()

        title_font = pygame.font.SysFont("consolas", 42, bold=True) or pygame.font.Font(None, 42)
        subtitle_font = pygame.font.SysFont("consolas", 24, bold=True) or pygame.font.Font(None, 24)

        pulse = (math.sin(self.elapsed * 4.0) + 1) * 0.5
        title_alpha = clamp(int(215 + pulse * 40))

        title_surf = title_font.render("This is for you, love", False, (255, 225, 235))
        subtitle_surf = subtitle_font.render("Thank you for every moment together", False, (255, 235, 245))
        continue_surf = self.unlock_small_font.render("Opening your surprise...", False, (190, 160, 190))

        title_surf.set_alpha(title_alpha)

        title_x = WIDTH // 2 - title_surf.get_width() // 2
        title_y = HEIGHT // 2 - 75
        subtitle_x = WIDTH // 2 - subtitle_surf.get_width() // 2
        subtitle_y = HEIGHT // 2 - 18
        continue_x = WIDTH // 2 - continue_surf.get_width() // 2
        continue_y = HEIGHT // 2 + 98

        glow = make_surface((520, 180))
        pygame.draw.ellipse(glow, (255, 90, 145, 36), (0, 20, 520, 130))
        self.canvas.blit(glow, (WIDTH // 2 - 260, HEIGHT // 2 - 115))

        self.canvas.blit(title_surf, (title_x, title_y))
        self.canvas.blit(subtitle_surf, (subtitle_x, subtitle_y))
        self.canvas.blit(continue_surf, (continue_x, continue_y))

        draw_pixel_heart(
            self.canvas,
            WIDTH // 2 - 34,
            HEIGHT // 2 + 38,
            (255, 91, 135),
            4,
            title_alpha,
        )
        draw_pixel_heart(
            self.canvas,
            WIDTH // 2 + 8,
            HEIGHT // 2 + 30,
            (255, 152, 188),
            3,
            clamp(int(title_alpha * 0.9)),
        )

    def draw(self):
        if self.state in ("date_gate", "location_gate"):
            self.draw_unlock_screen()
        elif self.state == "love_message":
            self.draw_love_message()
        else:
            self.draw_background()

            for firework in self.fireworks:
                firework.draw(self.canvas)

            self.draw_picnic_scene()
            self.text_manager.draw(self.canvas)

        # Draw click/tap hearts on top of every screen.
        for heart in self.cursor_hearts:
            heart.draw(self.canvas)

        # Desktop-only feeling: draw a pixel heart at the current mouse position.
        # On mobile, this is skipped shortly after touch input so it does not
        # leave a fake cursor on the screen.
        if self.elapsed - self.last_touch_time > 1.0:
            mouse_x, mouse_y = self.get_canvas_pos(pygame.mouse.get_pos())
            draw_pixel_heart(
                self.canvas,
                mouse_x - 7,
                mouse_y - 6,
                (255, 91, 135),
                2,
                230,
            )

        scaled = pygame.transform.scale(self.canvas, (SCREEN_WIDTH, SCREEN_HEIGHT))
        self.screen.blit(scaled, (0, 0))
        pygame.display.flip()


if __name__ == "__main__":
    asyncio.run(AnniversaryCard().run())